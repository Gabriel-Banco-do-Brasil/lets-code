public class Sum {

    void DisplaySum(double total){
        System.out.println("esse é o total = " + total);
    }
    
}
