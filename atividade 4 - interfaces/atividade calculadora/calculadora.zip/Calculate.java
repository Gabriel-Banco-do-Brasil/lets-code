public interface Calculate {
    double operate(double firstOperand, double secondOperand);

}
