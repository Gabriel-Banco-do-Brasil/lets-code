public class Sub implements Calculate{

    @Override
    public double operate(double firstOperand, double secondOperand) {
        return firstOperand - secondOperand;
    }
    
}
